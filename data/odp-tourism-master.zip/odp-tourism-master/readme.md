## OpenDataNepal Tourism Datasets
This repo contains the Tourism related datasets housed in http://data.opennepal.net/datasets_sector/167